Js Input Mask
===========

Pure Javascript based input mask



Please see Wiki Page(s) for instructions
